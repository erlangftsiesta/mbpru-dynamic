
module.exports = {
    content: ["../frontend/**/*.{html,ejs,js}"],
    theme: {
      extend: {},
    },
    plugins: [],
  }